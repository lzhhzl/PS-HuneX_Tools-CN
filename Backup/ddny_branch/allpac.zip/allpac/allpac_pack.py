import os
import struct

f=open("paclist.txt","r")
data2 = f.readlines()
f.close()
lenth = len(data2)-1


test2 = b""
test3 = b""
filename=["" for i in range(lenth)]
test = [[0 for i in range(2)]for j in range(lenth)]
test2 = [["" for i in range(2)]for j in range(lenth)]

for i in range(lenth):
    test2[i] = data2[i].replace("\n","").split(",")
    filename[i] = test2[i][0]
folder_path = './allpac_pack/'
file_list = os.listdir(folder_path)
for file in file_list:
    index=filename.index(file)
    filepath = f"./allpac_pack/{file}"
    print(file)
    f = open(filepath,"rb")
    datas = f.read()
    f.close()
    foresize = int(test2[index][1])
    lastofs = int(test2[index+1][1])

    nextnewofs = foresize + (len(datas) // 0x800 + 1) * 0x800
    newsize = len(datas)
    test2[index][2] = newsize
    f2=open("allpac.mrg","rb")
    forebuf = f2.read(foresize)
    f2.seek(lastofs,0)
    lastbuf = f2.read()
    f2.close()
    f3 = open("new_allpac.mrg","wb")
    f3.write(forebuf+datas)
    f3.seek(nextnewofs,0)
    f3.write(lastbuf)
    f3.close()

    diffofs = nextnewofs - lastofs

    for i in range(index + 1,lenth):
        test2[i][1] = str(int(test2[i][1]) + diffofs)

for i in range(lenth):
    offset = int(test2[i][1])
    size = int(test2[i][2])
    ofs_aligned = offset // 0x800
    ofs_low = ofs_aligned & 0xFFFF
    ofs_high = (ofs_aligned & 0xF0000) >> 4
    size_low = size & 0xFFFF
    if size_low == 0:
        size_sect = size // 0x800
    else:
        size_sect = size // 0x800 + 1
    test3 += struct.pack('<HHHH', ofs_low, ofs_high, size_sect, size_low)
f = open("new_allpac.hed","wb")
f.write(test3)
f.close()

