import struct
import io

f=open("allpac.nam","r",encoding="CP932",errors="ignore")
data2 = f.readlines()
f.close()
lenth = len(data2)-1


Entry = [[0 for i in range(2)]for j in range(lenth)]
filename=["" for i in range(lenth)]
text = ["" for i in range(lenth)]
file=open("allpac.hed","rb")
for i in range(lenth):
    datas = file.read(8)
    ofs_low, ofs_high, size_sect, size_low = struct.unpack('<HHHH', datas)
    offset = 0x800 * (ofs_low | ((ofs_high & 0xF000) << 4))
    rounded_size = size = 0x800 * size_sect
    if size_low == 0:
        size = rounded_size
    else:
        size = size_low | ((0x800 * (size_sect - 1)) & 0xFFFF0000)
    Entry[i][0], Entry[i][1] = offset, size
    filename[i] = data2[i].replace("\x00","").replace("\n","")
    text[i] =  f"{i}_"+filename[i] + "," + str(offset) + "," + str(size)
file.close()

file=open("allpac.mrg","rb")
for i in range(lenth):
    file.seek(Entry[i][0],0)
    outdatas = file.read(Entry[i][1])
    filename[i]= f"{i}_"+filename[i]
    output = open(f"allpac_unpack/"+filename[i],'wb')
    output.write(outdatas)
    output.close()
    print(filename[i],i)
file.close()

file=open(f"paclist.txt","w",encoding="CP932")
for i in range(lenth):
    file.writelines(text[i]+"\n")
file.close()



