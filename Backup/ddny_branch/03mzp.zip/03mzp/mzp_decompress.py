# -*- coding:utf-8 -*-
"""
coder:lzh
date:2023.09.03
"""
from pathlib import Path
import struct
# import sys
from _extract_mzp_tiles import MzpFile


def mrdg00_decompress(num,file):
    # 计算文件数和总体偏移量
    data_start_offset = (6 + 2 + num * 8)
    # 计算所有文件的数据偏移位和数据大小
    Entry = [[0 for i in range(2)]for j in range(num)]
    for i in range(num):
        datas = file.read(8)  # 每8字节对应单个文件的4个数据
        ofsSect,ofsByte,upperBoundSectCount,sizeRaw = struct.unpack('HHHH', datas)
        Real_offset = data_start_offset + ofsSect * 0x800 + ofsByte
        Real_size = (upperBoundSectCount - 1) // 0x20 * 0x800 * 0x20 + sizeRaw
        Entry[i][0],Entry[i][1] = Real_offset,Real_size

    return Entry


if __name__ == '__main__':
    file_path = './00_origin/'
    for file in Path(file_path).glob('**/*'):
        with file.open('rb') as file_data:
            # 确认文件头
            header = file_data.read(6)
            if header != b'mrgd00':
                print(f"{file.__str__()} is not MZP(mrgd00) format")
                continue
            print('Extracting from ' + file.name)
            num_of_entries = struct.unpack('<H', file_data.read(2))[0]
            if not num_of_entries:
                print(f"Error,{file.__str__()} find {num_of_entries} files")

            Entry = mrdg00_decompress(num_of_entries, file_data)
            # --bin(only extract to bin)
            # if args.bin:
            #     extract_bin(file, input_file, entries_descriptors, args.notmzx)
            # else:
            # extract to PNG
            try:
                mzp_file = MzpFile(file, file_data, Entry)
                mzp_file.extract_image()
                print(f"width:{mzp_file.width} height:{mzp_file.height} tile_width:{mzp_file.tile_width} tile_height:{mzp_file.tile_height}")
                print(f"tile_x_count:{mzp_file.tile_x_count} tile_y_count:{mzp_file.tile_y_count} bitmap_bpp:{mzp_file.bitmap_bpp}")
                print(f"bmp_type:{mzp_file.bmp_type} bmp_depth:{mzp_file.bmp_depth} tile_crop:{mzp_file.tile_crop}")
                print(f"row_width:{len(mzp_file.rows[0])} row_height:{len(mzp_file.rows)}")
            except:
                print("stop Extract ",file.name)
