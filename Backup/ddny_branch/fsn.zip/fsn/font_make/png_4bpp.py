from PIL import Image
from io import BytesIO

def png_bytes_to_4bpp_png(input_bytes,output_path):
    try:
        # Convert the input bytes to a PIL Image
        image_stream = BytesIO(input_bytes)
        image = Image.open(image_stream)

        # Convert the image to RGBA mode for quantization
        image = image.convert('RGBA')

        # Convert the image to 4bpp (4-bit color depth) using quantize method
        image = image.quantize(colors=16)

        # Save the image as PNG
        output_stream = BytesIO()
        image.save(output_stream, format="PNG")
        output_bytes = output_stream.getvalue()

        image.save(output_path, "PNG")
        print(f"Image saved to {output_path}")

        return output_bytes

    except Exception as e:
        print(f"Error: {e}")
        return None

# if __name__ == "__main__":
#     # Replace 'input_bytes' with your input byte stream
#     input_bytes = b'...'  # Replace with your actual input bytes
#
#     # Convert the input bytes to 4bpp PNG bytes
#     output_bytes = png_bytes_to_4bpp_png(input_bytes)
#
#     if output_bytes is not None:
#         # Save or process the output bytes as needed
#         with open("output_4bpp.png", "wb") as output_file:
#             output_file.write(output_bytes)
#         print("4bpp PNG image saved.")

# from PIL import Image
#
# def png_to_4bpp_png(input_path, output_path):
#     try:
#         # Open the existing PNG image
#         image = Image.open(input_path)
#
#         # Convert the image to RGB mode for quantization
#         image = image.convert('RGBA')
#
#         # Convert the image to 4bpp (4-bit color depth) using quantize method
#         image = image.quantize(colors=16)
#
#         # Save the image as PNG
#         image.save(output_path, "PNG")
#         print(f"Image saved to {output_path}")
#
#     except Exception as e:
#         print(f"Error: {e}")
#
#
# if __name__ == "__main__":
#     # Replace 'input.png' with the path to your existing PNG image
#     input_file_path = "output.png"
#
#     # Replace 'output_4bpp.png' with the desired output file path and name
#     output_file_path = "output_4bpp.png"
#
#     # Call the function to convert the PNG image to 4bpp
#     png_to_4bpp_png(input_file_path, output_file_path)
