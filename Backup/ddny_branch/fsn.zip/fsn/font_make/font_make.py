from PIL import Image, ImageDraw, ImageFont
import io
from png_4bpp import png_bytes_to_4bpp_png
from png_to_tile import read_png
from mgrd_compress import mrdg00_compress

def text_to_image(text, output_path, font_size=25, image_size=(512, 504), bg_color=(255, 255, 255, 0), text_color=(255, 255, 255, 255), border_color=(0, 0, 0, 255)):
    try:
        # Create a blank image with the specified background color (including alpha channel)
        image = Image.new('RGBA', image_size, bg_color)
        draw = ImageDraw.Draw(image)

        # Calculate the size of each small square image
        num_rows, num_cols = 14, 14
        small_image_size = (image_size[0] // num_cols, image_size[1] // num_rows)

        # Load a font
        font = ImageFont.truetype(f"msyhl.ttc", font_size)

        for row in range(num_rows):
            for col in range(num_cols):
                char_index = row * num_cols + col
                if char_index < len(text):
                    char = text[char_index]

                    # Calculate the position to center the text in each small square image
                    char_width, char_height = draw.textbbox((0, 0), char, font=font)[2:]
                    x_offset = (small_image_size[0] - char_width) // 2
                    y_offset = (small_image_size[1] - char_height) // 2
                    x = col * small_image_size[0] + x_offset
                    y = row * small_image_size[1] + y_offset

                    # Draw the white character with black border
                    draw.text((x - 1, y), char, fill=border_color, font=font)  # Black border
                    draw.text((x + 1, y), char, fill=border_color, font=font)  # Black border
                    draw.text((x, y - 1), char, fill=border_color, font=font)  # Black border
                    draw.text((x, y + 1), char, fill=border_color, font=font)  # Black border
                    draw.text((x, y), char, fill=text_color, font=font)  # White character

        # Save the image as PNG
        # image.save(output_path, "PNG")
        # print(f"Image saved to {output_path}")

        # Save the image as bytes
        img_bytes = io.BytesIO()
        image.save(img_bytes, format="PNG")
        img_bytes.seek(0)  # Reset the stream position to the beginning
        byte_4bpp = png_bytes_to_4bpp_png(img_bytes.read(), output_path)
        # print(byte_4bpp)
        font_buf = read_png(byte_4bpp, output_path)
        # return img_bytes.read()
        return font_buf



    except Exception as e:
        print(f"Error: {e}")


if __name__ == "__main__":

    text_color = (255, 255, 255, 255)

    #黑边为(0, 0, 0, 255)，白边(255, 255, 255, 255)
    border_color = (0, 0, 0, 255)

    f = open("常用字.txt", "r", encoding="utf-8")
    datas = f.read()
    f.close()
    fonts = [b"" for i in range(22)]
    for i in range(22):
        if i == 2:
            input_text=" 、。，．・：；？！゛ヽ" \
                       "ヾゝゞ〃々〆〇ー―‐〜‖｜…‥“" \
                       "”≪≫《》＜＞＿＋−×÷＝±" \
                       "αβγ（）■〈〉「」『』【】" \
                       "￥＄％＃＆＊＠※○●◇◆□▲" \
                       "♪★０１２３４５６７８９ＡＢ" \
                       "ＣＤＥＦＧＨＩＪＫＬＭＮＯＰ" \
                       "ＱＲＳＴＵＶＷＸＹＺａｂｃｄ" \
                       "ｅｆｇｈｉｊｋｌｍｎｏｐｑｒ" \
                       "ｓｔｕｖｗｘｙｚ"+datas[1:63]
        elif i>2:
            input_text = datas[(i-3) * 196 + 63 :(i-3) * 196 + 196 + 63]
        else:
            input_text = ""
        output_file_path = f"test4/{i}.png"
        # print(input_text)
        font_buf = text_to_image(input_text, output_file_path, text_color=text_color, border_color=border_color)
        fonts[i] = font_buf
    font_com = mrdg00_compress(fonts, len(fonts))
    f=open("test.bin","wb")
    f.write(font_com)
    f.close()
