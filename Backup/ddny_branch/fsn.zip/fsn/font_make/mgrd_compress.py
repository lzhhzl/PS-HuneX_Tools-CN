import os
import struct
from io import BytesIO

data_start_offset = (6 + 2 + 2 * 8)
def Offset(Real_offset):
    ofsSect = (Real_offset)//0x800
    ofsByte = (Real_offset)%0x800
    return ofsSect,ofsByte
def Size(Real_size):
    upperBoundSectCount = (Real_size)//(0x800 * 0x20) * 0x20 + 1
    sizeRaw = (Real_size)%(0x800 * 0x20)
    return upperBoundSectCount,sizeRaw




def mrdg00_compress(input_byte,num):
    prebuf,filebuf = b"",b""
    headbuf = b"\x6d\x72\x67\x64\x30\x30"+ struct.pack("<H", num)
    test = [[0 for i in range(2)] for j in range(num)]
    i = 0
    for i, file in enumerate(input_byte):
        f = BytesIO(file)
        if i == 0:
            Real_offset = 0
            Real_size = len(f.read())
        else:
            Real_offset = test[i - 1][1] + test[i - 1][0]
            Real_size = len(f.read())
        test[i][0] = Real_offset
        test[i][1] = Real_size
        # print(Offset(test[i][0]),Size(test[i][1]))
        ofsSect, ofsByte = Offset(test[i][0])
        upperBoundSectCount, sizeRaw = Size(test[i][1])
        prebuf += struct.pack("<HHHH", ofsSect, ofsByte, upperBoundSectCount, sizeRaw)
        filebuf += file
    buf = headbuf+prebuf+filebuf
    return buf




# for i, file in enumerate(sorted_file_list):
#     filepath = './test5/' + str(file)
#     # print(filepath)
#     f = open(filepath, "rb")
#     filebuf += f.read()
#     f.close()
#
# f = open("oudata.bin","wb")
# f.write(test2)
# f.close()
