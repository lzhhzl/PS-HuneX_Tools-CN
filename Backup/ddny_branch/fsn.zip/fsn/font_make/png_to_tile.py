import logging
from struct import unpack, pack
import io
import zlib
from io import BytesIO
from MZX_compress import mzx0_compress
from mgrd_compress import mrdg00_compress

class Byte(object):
    def __init__(self, number):
        self.number = number

    @property
    def high(self):
        return self.number >> 4

    @property
    def low(self):
        return self.number & 0x0F

def is_indexed_bitmap(bmp_info):
    return bmp_info == 0x01

def read_pngsig(f):
    sig = f.read(8)
    f.seek(4,1)

def read_ihdr(f):
    chunk_type = f.read(4)
    width, height, depth, color = unpack(">IIBB", f.read(10))
    f.seek(7,1)
    return width, height, depth, color

def read_plte(f):
    chunk_length = unpack(">I", f.read(4))[0]
    chunk_type = f.read(4)
    palette = f.read(chunk_length)
    palette = io.BytesIO(palette)
    f.seek(4, 1)
    return palette

def read_trns(f):
    chunk_length = unpack(">I", f.read(4))[0]
    chunk_type = f.read(4)
    transparency = f.read(chunk_length)
    transparency = io.BytesIO(transparency)
    f.seek(4, 1)
    return transparency

def read_idat(f):
    chunk_length = unpack(">I", f.read(4))[0]
    chunk_type = f.read(4)
    print(chunk_type)
    data = f.read(chunk_length)
    return zlib.decompress(data)

def transdata(dec_buf):
    buf=b''
    test = [b"" for i in range(513)]
    for i in range(504):
        test[i] = dec_buf[0+513*i:513+513*i]
        for j in range(1,len(test),2):
            buf += pack("B",(test[i][j+1]<<4) + test[i][j])
    return mzx0_compress(BytesIO(buf), len(buf))
    # return buf

def trans_palette(palette,transparency,bmp_type,bmp_depth):
    buf = b''
    if is_indexed_bitmap(bmp_type):
        if bmp_depth == 0x01:
            bitmap_bpp = 8
            palette_count = 0x100
        elif bmp_depth == 0x00 or bmp_depth == 0x10:
            bitmap_bpp = 4
            palette_count = 0x10
        elif bmp_depth == 0x11 or bmp_depth == 0x91:
            bitmap_bpp = 8
            palette_count = 0x100

        if bmp_depth in [0x00, 0x10]:
            for i in range(palette_count):
                r = palette.read(1)
                g = palette.read(1)
                b = palette.read(1)

                a = transparency.read(1)
                a = int.from_bytes(a, byteorder='big')
                if a == 0xFF:
                    temp_a = 0xFF
                else:
                    temp_a = ((a>>1)&0x3F) + (((a>>1)&0xC0)&((a<<6)&0xC0))
                rgbbuf = r + g + b + pack("<B",temp_a)
                buf += rgbbuf
            # print(buf)
            return buf


def read_png(input_bytes, output_path):
    f = BytesIO(input_bytes)
    read_pngsig(f)
    width, height, depth, color = read_ihdr(f)
    palette = read_plte(f)
    transparency = read_trns(f)
    bmp_type,bmp_depth = 1,0
    palettebuf = trans_palette(palette,transparency,bmp_type,bmp_depth)
    pixels = read_idat(f)
    pixelsbuf = transdata(pixels)
    tile_crop = 0
    tile_x_count = (width - width) + 1
    tile_y_count = (height - height) + 1
    prebuf = b''
    prebuf += pack('<HHHHHHHBB', width, height, width, height, tile_x_count, tile_y_count, bmp_type, bmp_depth, tile_crop)
    prebuf += palettebuf
    intput_byte = [b"" for i in range(2)]
    intput_byte[0] = prebuf
    intput_byte[1] = pixelsbuf
    buf = mrdg00_compress(intput_byte,len(intput_byte))
    # buf += pixelsbuf

    return buf


def png_to_tile(png_path):
    with open(png_path,'rb') as png_file:
        read_png(png_file)

# png_path = "test.png"
# png_to_tile(png_path)

#必须预存入bmp_type,bmp_depth的值