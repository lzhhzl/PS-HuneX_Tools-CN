import struct
import io
from trans_txt import trans_txt

def add_unique_prefix(lst, new_element):
    count = lst.count(new_element)
    if count > 0:
        new_element = f"{count + 1}_{new_element}"
    lst.append(new_element)
    return lst

def namelist(datas):
    dataslist = datas.split(b"\x00")
    namelist = []
    for bytes in dataslist:
        if bytes != b"":
            namelist = add_unique_prefix(namelist, bytes.decode("cp932").replace("\r\n","")+"\n")
    return namelist


def entry_export(i,name):
    file.seek(Entry[i][0], 0)
    outdatas = file.read(Entry[i][1])
    if i == 0:
        namelist1 = namelist(outdatas)
        output = open(f"00_origin/{i}.MZX", 'wb')
        output.write(outdatas)
        output.close()
        return namelist1
    else:
        output = open(name, 'wb')
        output.write(outdatas)
        output.close()


if __name__ == "__main__":
    file = open("allscr.mrg",'rb')
    file.seek(6,0)
    datas = file.read(2)
    num = struct.unpack('H', datas)[0]
    data_start_offset = (6 + 2 + num * 8)

    Entry = [[0 for i in range(2)]for j in range(num)]
    filelist = []

    for i in range(num):
        datas = file.read(8)
        ofsSect,ofsByte,upperBoundSectCount,sizeRaw = struct.unpack('HHHH', datas)
        Real_offset = data_start_offset + ofsSect * 0x800 + ofsByte
        Real_size = (upperBoundSectCount - 1) // 0x20 * 0x800 * 0x20 + sizeRaw
        Entry[i][0],Entry[i][1] = Real_offset,Real_size

    for i in range(num):
        if i == 0:
            name = f"00_origin/{i}.MZX"
            namelist1 = entry_export(i,name)
        elif i <len(namelist1) -1 and i>2:
            namelist1[i - 3] = namelist1[i - 3].replace("\n","")
            name = f"00_origin/{namelist1[i - 3]}.MZX"
            entry_export(i, name)
        else:
            name = f"00_origin/{i}.MZX"
            entry_export(i, name)
        filelist.append(name.replace("00_origin/","")+"\n")
        print(name)
    fw= open("name.list","w",encoding="utf-8")
    fw.writelines(filelist)
    fw.close()

    trans_txt()
    file.close()



