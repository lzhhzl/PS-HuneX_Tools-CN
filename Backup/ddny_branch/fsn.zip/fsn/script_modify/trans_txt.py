#!/usr/bin/env python3

# MZX Decompress Library
# Pure Python. Based on Mzx.cpp from ExtractData.
#
# FOR INTERNAL USE ONLY.
#
# Copyright (c) 2018 <hintay@me.com>
import io
from io import BytesIO
import os


def mzx0_decompress(f, inlen, exlen, xorff=False) -> [str, BytesIO]:
    """
    Decompress a block of data.
    """
    key = 0xFF

    out_data = BytesIO()  # slightly overprovision for writes past end of buffer
    ring_buf = [b'\xFF\xFF'] * 64 if xorff else [b'\x00\x00'] * 64
    ring_wpos = 0

    clear_count = 0
    max = f.tell() + inlen
    last = b'\xFF\xFF' if xorff else b'\x00\x00'

    while out_data.tell() < exlen:
        if f.tell() >= max:
            break
        if clear_count <= 0:
            clear_count = 0x1000
            last = b'\xFF\xFF' if xorff else b'\x00\x00'
        flags = ord(f.read(1))
        # print("+ %X %X %X" % (flags, f.tell(), out_data.tell()))

        clear_count -= 1 if (flags & 0x03) == 2 else flags // 4 + 1

        if flags & 0x03 == 0:
            out_data.write(last * ((flags // 4) + 1))

        elif flags & 0x03 == 1:
            k = 2 * (ord(f.read(1)) + 1)
            for i in range(flags // 4 + 1):
                out_data.seek(-k, 1)
                last = out_data.read(2)
                out_data.seek(0, 2)
                out_data.write(last)

        elif flags & 0x03 == 2:
            last = ring_buf[flags // 4]
            out_data.write(last)

        else:
            for i in range(flags // 4 + 1):
                last = ring_buf[ring_wpos] = bytes([byte ^ key for byte in f.read(2)]) if xorff else f.read(2)
                out_data.write(last)

                ring_wpos += 1
                ring_wpos %= 64
    status = "OK"

    out_data.truncate(exlen)  # Resize stream to decompress size
    out_data.seek(0)
    return [status, out_data]


def trans_txt():
    for file in os.listdir('./00_origin/'):
        # print(file)
        filepath = './00_origin/' + str(file)
        f = open(filepath, "rb")
        head = f.read(4)
        if head == b'MZX0':
            exlen = int.from_bytes(f.read(4), byteorder='little')
            inlen = len(f.read())
            f.seek(8,0)
            data = io.BytesIO(f.read())
            status, out_data = mzx0_decompress(data, inlen,exlen, xorff=True)
            byte = out_data.getvalue()
            string=byte.decode("CP932",errors="ignore")
            string = string.replace(";",";\n")

            fw = open('./01_script/' + str(file[0:-4])+".txt","w",encoding="utf-8")
            fw.write(string)
            fw.close()

            fw = open('./03_decode/' + str(file[0:-4]) + "_decode.MZX", "wb")
            fw.write(byte)
            fw.close()
            f.close()

        else:
            continue
        f.close()


