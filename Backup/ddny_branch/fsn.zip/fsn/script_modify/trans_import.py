import os
from modify_dict import diff_char
def modify_text_file(raw,original_text,modified_text,hex_mapping,data):
    origin_byte = b""
    modified_byte = b""
    for char in original_text:
        origin_byte += char.encode("CP932")
    for char in modified_text:
        # print(char)
        try:
            modified_byte += hex_mapping[char]
        except:
            modified_byte += char.encode("CP932")
    # print(origin_byte,modified_byte)
    # print(data)
    # data = data.replace(origin_byte,modified_byte)
    if origin_byte == modified_byte:
        return origin_byte,origin_byte
    else:
        return origin_byte, modified_byte

def newcode():
    f=open("Shift-JIS_test.txt","r",encoding="utf-8")
    datas = f.readlines()
    f.close()
    hex_mapping=[[""for i in range(2)]for j in range(len(datas))]
    for i in range(len(datas)):

        hex_mapping[i][0] = datas[i][-2]
        hex_mapping[i][1] = bytes.fromhex(datas[i][0:4])

    hex_to_hex_mapping = {hex_value: replacement for hex_value, replacement in hex_mapping}
    return hex_to_hex_mapping


if __name__ == "__main__":
    file_list = os.listdir("./02_modify_script")
    for file in file_list:
        f = open(f"./01_script/{file}","r",encoding="utf-8")
        text1=f.readlines()
        f.close()
        f = open(f"./02_modify_script/{file}", "r", encoding="utf-8")
        text2 = f.readlines()
        f.close()
        f = open(f"./03_decode/{file[0:-4]}_decode.MZX", "rb")
        datas = f.read()
        f.close()
        datas = datas.replace(b";_", b";\n_")
        datalist = datas.split(b"\n")
        text1_dict, text2_dict = diff_char(text1,text2)
        hex_mapping = newcode()
        print(file)

        common_text_key = set(text1_dict.keys()) & set(text2_dict.keys())

        for key in common_text_key:
            values1 = text1_dict[key]
            values2 = text2_dict[key]
            for val1, val2 in zip(values1, values2):
                # print(f"origin:{datalist[key]}")
                origin_byte,modified_byte = modify_text_file(key, val1, val2,hex_mapping,datalist[key])
                datalist[key] = datalist[key].replace(origin_byte,modified_byte)

        data = b"".join(datalist)

        fw= open(f"./04_modify/{file[0:-4]}_modify.MZX","wb")
        fw.write(data)
        fw.close()








