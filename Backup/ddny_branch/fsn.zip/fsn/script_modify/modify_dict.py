import os
def get_all_substrings(s):
    n = len(s)
    substrings = []
    for i in range(n):
        for j in range(i + 1, n + 1):
            substrings.append(s[i:j])
    return substrings


def all_substrings_of_both(s1, s2):
    all_subs_s1 = get_all_substrings(s1)
    all_subs_s2 = get_all_substrings(s2)

    return all_subs_s1, all_subs_s2


def common_substrings_with_constraints(list1, list2):
    common_subs = set()

    # Step 1: Find all common substrings
    for s1 in list1:
        for s2 in list2:
            if s1 == s2:
                common_subs.add(s1)

    result = set()

    # Step 2: Filter out substrings that are included in other substrings
    for sub in common_subs:
        is_included = False
        for other_sub in common_subs:
            if sub != other_sub and sub in other_sub:
                is_included = True
                break
        if not is_included:
            result.add(sub)

    return result

def diff_char(text1,text2):
    # 获取文件夹中的文件列表
    text1_dict = {}
    text2_dict = {}
    for i in range(len(text1)):
        string1 = text1[i]
        string2 = text2[i]
        if string1 != string2:
        # string1 = "bdadabcdkmg"
        # string2 = "mgbcabcd"
            text1_dict[i] = []
            all_subs_s1, all_subs_s2 = all_substrings_of_both(string1, string2)
            result = common_substrings_with_constraints(all_subs_s1, all_subs_s2)

            test1 = [0 for i in range(2*len(result))]
            j = 0
            for element in result:
                # print(i,element,string1.index(element),len(element))
                test1[j]=string1.index(element)
                test1[j+1] = string1.index(element)+len(element)
                j+=2
            test1 = sorted(test1)
            for j in range(len(test1)):
                if j==0:
                    str1 = string1[0:test1[j]]
                elif j<len(test1):
                    if test1[j-1] == test1[j]:
                        continue
                    else:
                        str1 = string1[test1[j-1]:test1[j]].replace("\n","")
                text1_dict[i].append(str1)
            # text1_dict[i].sort(key=len, reverse=True)

            text2_dict[i] = []
            test2 = [0 for i in range(2 * len(result))]
            j = 0
            for element in result:
                # print(i,element,string1.index(element),len(element))
                test2[j] = string2.index(element)
                test2[j + 1] = string2.index(element) + len(element)
                j += 2
            test2 = sorted(test2)
            # print(test2)
            for j in range(len(test2)):
                if j == 0:
                    str2 = string2[0:test2[j]]
                elif j < len(test1):
                    if test2[j - 1] == test2[j]:
                        continue
                    else:
                        str2 = string2[test2[j - 1]:test2[j]].replace("\n","")
                text2_dict[i].append(str2)
            # text2_dict[i].sort(key=len, reverse=True)

    return text1_dict,text2_dict





